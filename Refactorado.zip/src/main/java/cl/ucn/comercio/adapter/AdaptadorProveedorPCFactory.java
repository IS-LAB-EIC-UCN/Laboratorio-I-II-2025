package cl.ucn.comercio.adapter;

import java.util.List;

import cl.ucn.comercio.modelo.Producto;

public class AdaptadorProveedorPCFactory implements Adaptador {

	@Override
	public List<Producto> getCelulares(String marca, int anho, int pulgadas) {
		// TODO Auto-generated method stub
		return null;
	}

}
